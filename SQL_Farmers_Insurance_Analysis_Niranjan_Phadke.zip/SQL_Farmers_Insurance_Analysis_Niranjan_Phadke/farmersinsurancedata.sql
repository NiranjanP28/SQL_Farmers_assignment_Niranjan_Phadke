-- I) SELECT Queries

-- 1) Retrieve the names of all states (srcStateName)

SELECT DISTINCT srcStateName FROM ndap.farmersinsurancedata;

-- 2) Retrieve TotalFarmersCovered and SumInsured for each state,ordered descending byTotalFarmersCovered.

SELECT SUM(TotalFarmersCovered) as total_farmers_covered,SUM(SumInsured) as sum_insured,srcStateName
FROM ndap.farmersinsurancedata
GROUP BY srcStateName
ORDER BY total_farmers_covered DESC

-- II) FILTERING DATA

-- 3) Retrieve records where Year is 2020

     SELECT * FROM ndap.farmersinsurancedata
     WHERE YearCode=2020

-- 4) Retrieve records whereTotalPopulationRural > 10,00,000andsrcStateName = "HIMACHALPRADESH".

SELECT * FROM ndap.farmersinsurancedata
WHERE TotalPopulationRural >1000000 AND srcStateName='Himachal Pradesh'

-- 5) Retrieve the srcStateName,srcDistrictName, and the sum of FarmersPremiumAmount for each district in the year 2018, ordered by FarmersPremiumAmount in ascending order.

SELECT srcStateName,srcDistrictName, SUM(FarmersPremiumAmount) as farmers_premium_amt FROM ndap.farmersinsurancedata
WHERE srcYear=2018
GROUP BY srcDistrictName,srcStateName
ORDER BY farmers_premium_amt asc

-- 6) Retrieve the total number of farmers covered and the sum of the gross premium amount to be paid for each state where the insured land area is greater than 5.0 for the year 2018

SELECT srcStateName,SUM(TotalFarmersCovered) as total_farmers,SUM(GrossPremiumAmountToBePaid) as gross_premium_amt FROM ndap.farmersinsurancedata
WHERE YearCode=2018 AND InsuredLandArea >5
GROUP BY srcStateName
ORDER BY gross_premium_amt

-- III) AGGREGATION QUERIES (Group By)

-- 7) Calculate average InsuredLandArea for each year

Select YearCode,AVG(InsuredLandArea) as avg_insured_area  FROM ndap.farmersinsurancedata
GROUP BY YearCode

-- 8) Calculate TotalFarmersCovered for each district where InsuranceUnits > 0

SELECT SUM(TotalFarmersCovered) as total_farmers_covered,srcDistrictName as district_name
FROM ndap.farmersinsurancedata
WHERE InsuranceUnits > 0
GROUP BY district_name

-- 9) Calculate total premiums and TotalFarmersCovered for each state where total SumInsured >5,00,000INR

SELECT SUM(GrossPremiumAmountToBePaid) as total_premium, SUM(TotalFarmersCovered) as total_farmers,srcStateName
FROM ndap.farmersinsurancedata
WHERE (SumInsured * 100000)> 500000
GROUP BY srcStateName

-- IV) SORTING DATA (ORDER BY)

-- 10) Retrieve the top 5 districts with the highest total population in 2020

Select srcDistrictName, TotalPopulation
FROM ndap.farmersinsurancedata
WHERE yearcode=2020
ORDER BY TotalPopulation DESC
LIMIT 5

-- 11)Retrieve srcStateName,srcDistrictName, and SumInsured for the 10 districts with lowest non-zero farmers’ premium amount, ordered by insured sum and premium amount

SELECT srcStateName,srcDistrictName, SumInsured 
FROM ndap.farmersinsurancedata
WHERE FarmersPremiumAmount >0
ORDER BY SumInsured,FarmersPremiumAmount ASC
LIMIT 10

-- 12) Retrieve top 3 states for each year with highest insured farmers to total population ratio, ordered by the ratio

SELECT yearCode, srcStateName, (SUM(TotalFarmersCovered)) /SUM(TotalPopulation) *100) AS coverage_ratio
FROM ndap.farmersinsurancedata
GROUP BY srcStateName
ORDER BY coverage_ratio ASC
LIMIT 3

-- V) String Functions

-- 13) Retrieve the first 3 characters of thesrcStateName to createStateShortName.

ALTER TABLE farmersinsurancedata
ADD state_short_name VARCHAR (255);
Update ndap.farmersinsurancedata
set state_short_name =LEFT (srcStateName,3);
SELECT DISTINCT state_short_name from ndap.farmersinsurancedata

-- 14)  Retrieve srcDistrictName where the district name starts with"B"

SELECT DISTINCT srcDistrictName FROM ndap.farmersinsurancedata
WHERE srcDistrictName LIKE 'B%'

-- 15) Retrieve srcStateName and srcDistrictName where district name ends with"pur".

SELECT DISTINCT srcStateName,srcDistrictName FROM ndap.farmersinsurancedata
WHERE srcDistrictName LIKE '%pur'

-- VI) JOINS

-- 16) INNER JOIN srcStateName and srcDistrictName to retrieve the aggregated farmers’ premium amount for districts where the Insurance units for an individual year are greater than 10.

SELECT d1.yearcode, d1.FarmersPremiumAmount AS aggr_farm_premium, d1.srcStateName AS srcStateName1,
d1.srcDistrictName AS srcDistrictName1,d2.srcStateName AS srcStateName2,
d2.srcDistrictName AS srcDistrictName2 FROM ndap.farmersinsurancedata d1
INNER JOIN ndap.farmersinsurancedata d2
ON d1.rowID=d2.rowID
WHERE d1.InsuranceUnits > 10

-- 17) Retrieve srcStateName,srcDistrictName,Year,TotalPopulationfor each district and the highest recorded farmers premium amount 
-- for that district over all available years. Return only those districts where the highest amount exceeds 20 crores

SELECT d1.yearcode, d1.FarmersPremiumAmount , d1.srcStateName,
d1.srcDistrictName , d1.TotalPopulation FROM ndap.farmersinsurancedata d1
INNER JOIN ndap.farmersinsurancedata d2
ON d1.rowID=d2.rowID
WHERE ( d1.FarmersPremiumAmount*100000) > 200000000

-- 18) Perform a LEFT JOIN to combine the total population statistics with the farmers’ data for each district and state. 
--     Return the total premium amount and the average population count for each district aggregated over the years, where the total premium amount is greater than 100 crores.
--     Sort the results by total farmers’ premium amount, highest first

SELECT d1.yearCode,d1.GrossPremiumAmountToBePaid AS total_premium, d1.TotalPopulation , d1.srcStateName,
d1.srcDistrictName FROM ndap.farmersinsurancedata d1
LEFT JOIN ndap.farmersinsurancedata d2
ON d1.rowID=d2.rowID
WHERE (d1.GrossPremiumAmountToBePaid*100000) > 1000000000
ORDER BY d1.FarmersPremiumAmount DESC

-- VII) SUBQUERIES

-- 19) Find districts where the total farmers covered is greater than average total farmers covered across all records

SELECT DISTINCT srcDistrictName FROM ndap.farmersinsurancedata
WHERE TotalFarmersCovered > (SELECT AVG(TotalFarmersCovered) FROM ndap.farmersinsurancedata)

-- 20) Find srcStateName where insured sum is higher than insured sum of the district with the highest farmers premium amount.

SELECT DISTINCT(srcStateName) FROM ndap.farmersinsurancedata
WHERE SumInsured > (SELECT FarmersPremiumAmount FROM ndap.farmersinsurancedata
ORDER BY FarmersPremiumAmount DESC LIMIT 1)

-- 21) Find src DistrictName where farmers premium amount is higher than average farmers premium amount of the state with highest total population

SELECT DISTINCT(srcDistrictName) FROM ndap.farmersinsurancedata
WHERE FarmersPremiumAmount > (SELECT AVG(FarmersPremiumAmount) FROM ndap.farmersinsurancedata
WHERE srcStateName= (SELECT srcStateName FROM (SELECT srcStateName, SUM(TotalPopulation) AS total_population
            FROM ndap.farmersinsurancedata
GROUP BY srcStateName ORDER BY SUM(TotalPopulation) DESC LIMIT 1) AS pop))

-- VIII) Advanced SQL functions (Window Functions)

-- 22) Use ROW_NUMBER()to rank records ordered by the total farmers covered

SELECT 
    ROW_NUMBER() OVER (ORDER BY TotalFarmersCovered) AS row_num,
    yearCode,SrcStateName,SrcDistrictName,TotalFarmersCovered
FROM ndap.farmersinsurancedata

-- 23) Use RANK()to rank districts based on insured sum partitioned by srcStateName.

SELECT srcDistrictName, srcStateName, SumInsured,
RANK() OVER (PARTITION BY srcStateName ORDER BY SumInsured) AS district_rank
FROM ndap.farmersinsurancedata

-- 24) Use SUM() window function to calculate cumulative farmers’ premium amount for each district partitioned by srcStateName

SELECT DISTINCT srcDistrictName,
SUM(FarmersPremiumAmount) OVER (PARTITION BY srcStateName ORDER BY srcDistrictName) AS total_premium
FROM ndap.farmersinsurancedata

-- IX) DATA INTEGRITY (CONSTRAINTS, FOREIGN KEYS)

-- 25) Create a tabledistrictswithDistrictCodeas the primary key and columns forDistrictNameandStateCode. 
--     Create another tablestateswithStateCodeas primary key and column forStateName.

USE ndap;
CREATE TABLE districts (
DistrictCode INT PRIMARY KEY,
DistrictName VARCHAR(255),
StateCode INT
);

CREATE TABLE states (
StateCode INT PRIMARY KEY,
StateName VARCHAR(255)
);

-- 26) Add a foreign key constraint to the districts table referencingStateCodefrom the states table.

ALTER TABLE districts
ADD CONSTRAINT fk_constraint_name
FOREIGN KEY (StateCode)
REFERENCES states(StateCode)

-- X) Update and Delete

-- 27) Update FarmersPremiumAmount to 500.0 INR where rowID = 1

UPDATE ndap.farmersinsurancedata
SET FarmersPremiumAmount= 500
WHERE rowID='1' ;

-- 28) Update year to 2021 for records wheresrcStateName = "HIMACHAL PRADESH"

UPDATE ndap.farmersinsurancedata
SET Yearcode= 2021
WHERE srcStateName='Himachal Pradesh';

-- 29) Delete records where TotalFarmersCovered < 10,000 and Year = 2020

DELETE FROM ndap.farmersinsurancedata
WHERE TotalFarmersCovered < 10000 and Yearcode = 2020






